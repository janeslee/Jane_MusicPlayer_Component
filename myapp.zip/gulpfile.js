function defaultTask(cb) {
  // example
  cb();
}

exports.default = defaultTask